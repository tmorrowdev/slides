---
theme: seriph
background: https://source.unsplash.com/collection/94734566/1920x1080
class: 'text-center'
highlighter: shiki
lineNumbers: true
info: |
  ## Custom States API
  A deep dive into the future of web interactivity
drawings:
  persist: false
css: unocss
---

# Custom States API

Building the next generation of web interactions

<div class="pt-12">
  <span @click="$slidev.nav.next" class="px-2 py-1 rounded cursor-pointer" hover="bg-white bg-opacity-10">
    Press Space for next page <carbon:arrow-right class="inline"/>
  </span>
</div>

---

# What is the Custom States API?

The Custom States API allows developers to:

- 📱 Define custom states for elements
- 🎨 Style elements based on custom states
- 🔄 Manage state transitions programmatically
- 🎯 Create more semantic interactions

```js
// Creating a custom state
element.states.add('expanded');

// Removing a custom state
element.states.delete('expanded');

// Checking if a state exists
element.states.has('expanded');
```

---

# Use Cases

<div grid="~ cols-2 gap-4">
<div>

### Common Scenarios
- Custom toggles
- Complex form states
- Multi-step animations
- Game states
- Interactive tutorials

</div>
<div>

### Benefits
- More semantic than data attributes
- Better performance
- Native browser support
- Cleaner markup
- Enhanced accessibility

</div>
</div>

---

# Styling Custom States

```css {all|1-4|6-9|all}
/* Basic state styling */
[states~="expanded"] {
  height: auto;
}

/* Combining with pseudo-classes */
[states~="selected"]:hover {
  background-color: #e0e0e0;
}
```

<div v-click class="mt-8">

### Key Points
- Uses attribute selector syntax
- Can be combined with other selectors
- Supports multiple states
- Works with CSS transitions

</div>

---

# JavaScript API

```js {monaco}
class CustomStatesDemo {
  constructor(element) {
    this.element = element;
  }

  expand() {
    this.element.states.add('expanded');
  }

  collapse() {
    this.element.states.delete('expanded');
  }

  toggle() {
    if (this.element.states.has('expanded')) {
      this.collapse();
    } else {
      this.expand();
    }
  }
}
```

---

# Real-World Example

<div grid="~ cols-2 gap-4">

```html
<button id="menu-toggle">
  Toggle Menu
</button>
<nav id="menu">
  <ul>
    <li>Home</li>
    <li>About</li>
    <li>Contact</li>
  </ul>
</nav>
```

```js
const menu = document.querySelector('#menu');
const toggle = document.querySelector('#menu-toggle');

toggle.addEventListener('click', () => {
  menu.states.toggle('expanded');
});
```

</div>

---

# Browser Support & Polyfills

<div class="grid grid-cols-2 gap-4">
<div>

### Current Support
- Chrome (Experimental)
- Edge (Behind flag)
- Firefox (In development)
- Safari (Not yet)

</div>
<div>

### Polyfill Usage
```js
if (!('states' in Element.prototype)) {
  // Simple polyfill
  Element.prototype.states = new Set();
}
```

</div>
</div>

---
layout: center
class: text-center
---

# Thank You!

Learn more about Custom States API:
[MDN Docs](https://developer.mozilla.org) · [W3C Spec](https://w3c.github.io) · [Examples](https://github.com)